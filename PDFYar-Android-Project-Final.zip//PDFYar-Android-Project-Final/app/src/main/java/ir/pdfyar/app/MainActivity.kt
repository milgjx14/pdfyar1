package ir.pdfyar.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var lastBackPressedAt: Long = 0L

    private data class PendingUpload(
        val fileName: String,
        val mimeType: String,
        val tempFile: File
    )

    private val pendingUploads = ConcurrentHashMap<String, PendingUpload>()
    @Volatile
    private var lastSavedUri: Uri? = null
    @Volatile
    private var lastSavedMime: String = "application/pdf"

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val callback = filePathCallback
        filePathCallback = null
        if (callback == null) return@registerForActivityResult

        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val data = result.data!!
            val uris = mutableListOf<Uri>()
            val clipData = data.clipData
            if (clipData != null && clipData.itemCount > 0) {
                for (i in 0 until clipData.itemCount) {
                    clipData.getItemAt(i)?.uri?.let { uris.add(it) }
                }
            } else {
                data.data?.let { uris.add(it) }
            }
            callback.onReceiveValue(if (uris.isNotEmpty()) uris.toTypedArray() else null)
        } else {
            callback.onReceiveValue(null)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Request legacy storage permission only on Android 7 - 9
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                    1001
                )
            }
        }

        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            overScrollMode = WebView.OVER_SCROLL_NEVER
        }
        setContentView(webView)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            databaseEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            cacheMode = WebSettings.LOAD_DEFAULT
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }

        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback

                val allowMultiple =
                    fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE

                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    if (allowMultiple) {
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    }
                }

                return try {
                    filePickerLauncher.launch(Intent.createChooser(intent, "انتخاب فایل"))
                    true
                } catch (e: Exception) {
                    this@MainActivity.filePathCallback?.onReceiveValue(null)
                    this@MainActivity.filePathCallback = null
                    Toast.makeText(
                        this@MainActivity,
                        "خطا در باز کردن مدیر فایل",
                        Toast.LENGTH_SHORT
                    ).show()
                    false
                }
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript(
                    "(function(){ return window.handleAndroidBack ? window.handleAndroidBack() : 'home'; })();"
                ) { result ->
                    val cleaned = result?.replace("\"", "") ?: "home"
                    if (cleaned == "home") {
                        val now = System.currentTimeMillis()
                        if (now - lastBackPressedAt < 2000L) {
                            finish()
                        } else {
                            lastBackPressedAt = now
                            Toast.makeText(
                                this@MainActivity,
                                "برای خروج دوباره دکمه بازگشت را بزنید",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            }
        })

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun sanitizeFileName(raw: String): String {
        val cleaned = raw.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        return if (cleaned.isBlank()) "pdfyar_output.pdf" else cleaned
    }

    private fun commitTempFileToDownloads(
        tempFile: File,
        fileName: String,
        mimeType: String
    ): Pair<Boolean, String> {
        val safeName = sanitizeFileName(fileName)
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                    put(MediaStore.Downloads.MIME_TYPE, mimeType)
                    put(
                        MediaStore.Downloads.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/PDFYar"
                    )
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val resolver = contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return Pair(false, "خطا در ایجاد فایل در حافظه")

                resolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(tempFile).use { input ->
                        input.copyTo(out)
                    }
                } ?: return Pair(false, "خطا در نوشتن فایل")

                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, values, null, null)

                lastSavedUri = uri
                lastSavedMime = mimeType
                tempFile.delete()
                Pair(true, "Downloads/PDFYar/$safeName")
            } else {
                @Suppress("DEPRECATION")
                val downloadsDir = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS
                )
                val targetDir = File(downloadsDir, "PDFYar")
                if (!targetDir.exists()) targetDir.mkdirs()

                val outFile = if (targetDir.exists() && targetDir.canWrite()) {
                    File(targetDir, safeName)
                } else {
                    val fallbackDir = File(
                        getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                        "PDFYar"
                    )
                    if (!fallbackDir.exists()) fallbackDir.mkdirs()
                    File(fallbackDir, safeName)
                }

                FileInputStream(tempFile).use { input ->
                    FileOutputStream(outFile).use { out ->
                        input.copyTo(out)
                    }
                }
                MediaScannerConnection.scanFile(
                    this,
                    arrayOf(outFile.absolutePath),
                    arrayOf(mimeType),
                    null
                )
                lastSavedUri = FileProvider.getUriForFile(
                    this,
                    "$packageName.fileprovider",
                    outFile
                )
                lastSavedMime = mimeType
                tempFile.delete()
                Pair(true, "Downloads/PDFYar/$safeName")
            }
        } catch (e: Exception) {
            Pair(false, e.localizedMessage ?: "خطای ناشناخته در ذخیره فایل")
        }
    }

    inner class AndroidBridge {

        @JavascriptInterface
        fun isAndroidApp(): Boolean = true

        @JavascriptInterface
        fun startFile(fileName: String, mimeType: String): String {
            val id = UUID.randomUUID().toString()
            val dir = File(cacheDir, "exports")
            if (!dir.exists()) dir.mkdirs()
            val tempFile = File(dir, "$id.tmp")
            if (tempFile.exists()) tempFile.delete()
            pendingUploads[id] = PendingUpload(fileName, mimeType, tempFile)
            return id
        }

        @JavascriptInterface
        fun appendChunk(uploadId: String, base64Chunk: String): Boolean {
            val item = pendingUploads[uploadId] ?: return false
            return try {
                val bytes = Base64.decode(base64Chunk, Base64.DEFAULT)
                FileOutputStream(item.tempFile, true).use { it.write(bytes) }
                true
            } catch (e: Exception) {
                false
            }
        }

        @JavascriptInterface
        fun finishFile(uploadId: String): String {
            val item = pendingUploads.remove(uploadId)
                ?: return JSONObject().put("ok", false).put("error", "آپلود پیدا نشد").toString()

            val (ok, msg) = commitTempFileToDownloads(item.tempFile, item.fileName, item.mimeType)
            runOnUiThread {
                val toastText = if (ok) "ذخیره شد در: $msg" else "خطا در ذخیره: $msg"
                Toast.makeText(this@MainActivity, toastText, Toast.LENGTH_LONG).show()
            }
            return JSONObject()
                .put("ok", ok)
                .put("path", msg)
                .toString()
        }

        @JavascriptInterface
        fun saveFile(base64Data: String, fileName: String, mimeType: String): String {
            val id = startFile(fileName, mimeType)
            val okChunk = appendChunk(id, base64Data)
            return if (okChunk) {
                finishFile(id)
            } else {
                pendingUploads.remove(id)?.tempFile?.delete()
                JSONObject().put("ok", false).put("error", "خطا در پردازش فایل").toString()
            }
        }

        @JavascriptInterface
        fun shareLastFile(): Boolean {
            val uri = lastSavedUri ?: return false
            val mime = lastSavedMime
            runOnUiThread {
                try {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = mime
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(shareIntent, "اشتراک‌گذاری فایل"))
                } catch (e: Exception) {
                    Toast.makeText(
                        this@MainActivity,
                        "برنامه‌ای برای اشتراک‌گذاری یافت نشد",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            return true
        }

        @JavascriptInterface
        fun setTheme(isDark: Boolean) {
            runOnUiThread {
                val statusBarBg = if (isDark) Color.parseColor("#0F172A") else Color.parseColor("#F8FAFC")
                val navBarBg = if (isDark) Color.parseColor("#1E293B") else Color.parseColor("#FFFFFF")
                window.statusBarColor = statusBarBg
                window.navigationBarColor = navBarBg
                val controller = WindowInsetsControllerCompat(window, window.decorView)
                controller.isAppearanceLightStatusBars = !isDark
                controller.isAppearanceLightNavigationBars = !isDark
            }
        }
    }

    override fun onDestroy() {
        pendingUploads.values.forEach { it.tempFile.delete() }
        pendingUploads.clear()
        webView.destroy()
        super.onDestroy()
    }
}
